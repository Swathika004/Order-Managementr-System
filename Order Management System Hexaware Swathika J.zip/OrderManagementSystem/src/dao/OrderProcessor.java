package dao;

import entity.*;
import util.DBConnUtil;
import exception.*;
import java.sql.*;
import java.util.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Types;


public class OrderProcessor implements IOrderManagementRepository {

    @Override
    public void createUser(User user) {
    	System.out.println(user.getUsername());
        try (Connection conn = DBConnUtil.getConnection()) {
            PreparedStatement ps = conn.prepareStatement("INSERT INTO Users (userId, username, password, role) VALUES (?, ?, ?, ?)");
            ps.setInt(1, user.getUserId());
            ps.setString(2, user.getUsername());
            ps.setString(3, user.getPassword());
            ps.setString(4, user.getRole());
            ps.executeUpdate();
            System.out.println("User created.");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void createProduct(User user, Product product) {
        if (!user.getRole().equalsIgnoreCase("Admin")) {
            System.out.println("Only admin can create products.");
            return;
        }

        try (Connection conn = DBConnUtil.getConnection()) {
            PreparedStatement ps = conn.prepareStatement(
                "INSERT INTO Products (productId, productName, description, price, quantityInStock, type, brand, warrantyPeriod, size, color) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

            ps.setInt(1, product.getProductId());
            ps.setString(2, product.getProductName());
            ps.setString(3, product.getDescription());
            ps.setDouble(4, product.getPrice());
            ps.setInt(5, product.getQuantityInStock());
            ps.setString(6, product.getType());

            // Handle subclass-specific fields
            if (product instanceof Electronics) {
                Electronics e = (Electronics) product;
                ps.setString(7, e.getBrand());
                ps.setInt(8, e.getWarrantyPeriod());
                ps.setNull(9, Types.VARCHAR);
                ps.setNull(10, Types.VARCHAR);
            } else if (product instanceof Clothing) {
                Clothing c = (Clothing) product;
                ps.setNull(7, Types.VARCHAR);
                ps.setNull(8, Types.INTEGER);
                ps.setString(9, c.getSize());
                ps.setString(10, c.getColor());
            } else {
                ps.setNull(7, Types.VARCHAR);
                ps.setNull(8, Types.INTEGER);
                ps.setNull(9, Types.VARCHAR);
                ps.setNull(10, Types.VARCHAR);
            }

            ps.executeUpdate();
            System.out.println("Product created.");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public List<Product> getAllProducts() {
        List<Product> productList = new ArrayList<>();
        try (Connection conn = DBConnUtil.getConnection()) {
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery("SELECT * FROM Products");
            while (rs.next()) {
                String type = rs.getString("type");
                if ("Electronics".equalsIgnoreCase(type)) {
                    Electronics e = new Electronics(
                            rs.getInt("productId"),
                            rs.getString("productName"),
                            rs.getString("description"),
                            rs.getDouble("price"),
                            rs.getInt("quantityInStock"),
                            type,
                            rs.getString("brand"),
                            rs.getInt("warrantyPeriod")
                    );
                    productList.add(e);
                } else if ("Clothing".equalsIgnoreCase(type)) {
                    Clothing c = new Clothing(
                            rs.getInt("productId"),
                            rs.getString("productName"),
                            rs.getString("description"),
                            rs.getDouble("price"),
                            rs.getInt("quantityInStock"),
                            type,
                            rs.getString("size"),
                            rs.getString("color")
                    );
                    productList.add(c);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return productList;
    }

    @Override
    public void createOrder(User user, List<Product> products) {
        try (Connection conn = DBConnUtil.getConnection()) {
            // Check if user exists
            PreparedStatement checkUser = conn.prepareStatement("SELECT * FROM Users WHERE userId = ?");
            checkUser.setInt(1, user.getUserId());
            ResultSet rs = checkUser.executeQuery();

            // If user doesn't exist, create the user
            if (!rs.next()) {
                System.out.println("User not found. Creating new user...");
                createUser(user); // reusing your existing method
            }

            // Create order for each product
            PreparedStatement ps = conn.prepareStatement(
                    "INSERT INTO Orders (userId, productId) VALUES (?, ?)");

            for (Product p : products) {
                ps.setInt(1, user.getUserId());
                ps.setInt(2, p.getProductId());
                ps.addBatch();
            }

            ps.executeBatch();
            System.out.println("Order created for user ID: " + user.getUserId());

        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    @Override
    public void cancelOrder(int userId, int orderId) {
        try (Connection conn = DBConnUtil.getConnection()) {
            // Check user exists
            PreparedStatement userCheck = conn.prepareStatement("SELECT * FROM Users WHERE userId = ?");
            userCheck.setInt(1, userId);
            ResultSet userRs = userCheck.executeQuery();

            if (!userRs.next()) {
                throw new UserNotFoundException("User ID not found: " + userId);
            }

            // Check order exists
            PreparedStatement orderCheck = conn.prepareStatement("SELECT * FROM Orders WHERE orderId = ?");
            orderCheck.setInt(1, orderId);
            ResultSet orderRs = orderCheck.executeQuery();

            if (!orderRs.next()) {
                throw new OrderNotFoundException("Order ID not found: " + orderId);
            }

            // Delete the order
            PreparedStatement ps = conn.prepareStatement("DELETE FROM Orders WHERE orderId = ?");
            ps.setInt(1, orderId);
            ps.executeUpdate();

            System.out.println("Order ID " + orderId + " canceled for user ID " + userId);

        } catch (UserNotFoundException | OrderNotFoundException e) {
            System.out.println("❌ " + e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public List<Product> getOrderByUser(User user) {
        List<Product> orderedProducts = new ArrayList<>();

        try (Connection conn = DBConnUtil.getConnection()) {
            // Join Orders with Products
            PreparedStatement ps = conn.prepareStatement(
                    "SELECT p.* FROM Orders o " +
                    "JOIN Products p ON o.productId = p.productId " +
                    "WHERE o.userId = ?");

            ps.setInt(1, user.getUserId());
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                String type = rs.getString("type");

                if ("Electronics".equalsIgnoreCase(type)) {
                    Electronics e = new Electronics(
                            rs.getInt("productId"),
                            rs.getString("productName"),
                            rs.getString("description"),
                            rs.getDouble("price"),
                            rs.getInt("quantityInStock"),
                            type,
                            rs.getString("brand"),
                            rs.getInt("warrantyPeriod")
                    );
                    orderedProducts.add(e);
                } else if ("Clothing".equalsIgnoreCase(type)) {
                    Clothing c = new Clothing(
                            rs.getInt("productId"),
                            rs.getString("productName"),
                            rs.getString("description"),
                            rs.getDouble("price"),
                            rs.getInt("quantityInStock"),
                            type,
                            rs.getString("size"),
                            rs.getString("color")
                    );
                    orderedProducts.add(c);
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return orderedProducts;
    }

}

