package main;

import dao.*;
import entity.*;
import java.util.*;

public class OrderManagement {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        OrderProcessor processor = new OrderProcessor();

        while (true) {
        	System.out.println("\n--- Order Management System ---");
        	System.out.println("1. Create User");
        	System.out.println("2. Create Product");
        	System.out.println("3. Show All Products");
        	System.out.println("4. Create Order");
        	System.out.println("5. Cancel Order");
        	System.out.println("6. View Orders by User");
        	System.out.println("7. Exit");
        	System.out.print("Enter your choice: ");

            
            int ch = sc.nextInt();

            switch (ch) {
            case 1:
                System.out.print("Enter User ID: ");
                int userId = sc.nextInt();
                sc.nextLine();
                System.out.print("Enter Username: ");
                String username = sc.nextLine();
                System.out.print("Enter Password: ");
                String password = sc.nextLine();
                System.out.print("Enter Role (Admin/User): ");
                String role = sc.nextLine();
                User user = new User(userId, username, password, role);
                processor.createUser(user);
                break;

            case 2:
                System.out.print("Is it Electronics or Clothing? ");
                String type = sc.next();
                System.out.print("Enter Admin User ID to verify: ");
                int uid = sc.nextInt();
                User admin = new User();
                admin.setUserId(uid);
                admin.setRole("Admin");

                System.out.print("Enter Product ID: ");
                int pid = sc.nextInt();
                sc.nextLine();
                System.out.print("Enter Name: ");
                String pname = sc.nextLine();
                System.out.print("Enter Description: ");
                String desc = sc.nextLine();
                System.out.print("Enter Price: ");
                double price = sc.nextDouble();
                System.out.print("Enter Quantity: ");
                int qty = sc.nextInt();

                if ("Electronics".equalsIgnoreCase(type)) {
                    sc.nextLine();
                    System.out.print("Enter Brand: ");
                    String brand = sc.nextLine();
                    System.out.print("Enter Warranty Period: ");
                    int warranty = sc.nextInt();
                    Product ep = new Electronics(pid, pname, desc, price, qty, "Electronics", brand, warranty);
                    processor.createProduct(admin, ep);
                } else if ("Clothing".equalsIgnoreCase(type)) {
                    sc.nextLine();
                    System.out.print("Enter Size: ");
                    String size = sc.nextLine();
                    System.out.print("Enter Color: ");
                    String color = sc.nextLine();
                    Product cp = new Clothing(pid, pname, desc, price, qty, "Clothing", size, color);
                    processor.createProduct(admin, cp);
                }
                break;

            case 3:
                List<Product> products = processor.getAllProducts();
                for (Product p : products) {
                    System.out.println(p.getProductName() + " - ₹" + p.getPrice());
                }
                break;

            case 4:
                System.out.print("Enter User ID: ");
                int uid4 = sc.nextInt();
                sc.nextLine();
                System.out.print("Enter number of products to order: ");
                int n = sc.nextInt();
                List<Product> orderProducts = new ArrayList<>();

                for (int i = 0; i < n; i++) {
                    System.out.print("Enter Product ID to order: ");
                    int orderPid = sc.nextInt();
                    Product p = new Product();
                    p.setProductId(orderPid);
                    orderProducts.add(p);
                }

                sc.nextLine();
                System.out.print("Enter Username: ");
                String uname = sc.nextLine();
                System.out.print("Enter Password: ");
                String upass = sc.nextLine();
                User orderUser = new User(uid4, uname, upass, "User");
                processor.createOrder(orderUser, orderProducts);
                break;

            case 5:
                System.out.print("Enter User ID: ");
                int cancelUid = sc.nextInt();
                System.out.print("Enter Order ID to cancel: ");
                int orderId = sc.nextInt();
                processor.cancelOrder(cancelUid, orderId);
                break;

            case 6:
                System.out.print("Enter User ID: ");
                int searchId = sc.nextInt();
                User searchUser = new User();
                searchUser.setUserId(searchId);
                List<Product> userOrders = processor.getOrderByUser(searchUser);
                System.out.println("Products ordered by user ID " + searchId + ":");
                for (Product p : userOrders) {
                    System.out.println(p.getProductName() + " - ₹" + p.getPrice());
                }
                break;

            case 7:
                System.out.println("Exiting...");
                System.exit(0);
        }

        }
    }
}
