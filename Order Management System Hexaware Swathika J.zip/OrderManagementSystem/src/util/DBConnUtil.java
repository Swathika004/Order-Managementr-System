package util;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBConnUtil {
    public static Connection getConnection() {
        try {
            String filePath = "resources/db.properties";
            String url = DBPropertyUtil.getProperty(filePath, "url");
            String user = DBPropertyUtil.getProperty(filePath, "user");
            String password = DBPropertyUtil.getProperty(filePath, "password");
            System.out.println(user);
            Class.forName("com.mysql.cj.jdbc.Driver");
            return DriverManager.getConnection(url, user, password);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}
