package util;

import java.io.FileReader;
import java.util.Properties;

public class DBPropertyUtil {
    public static String getProperty(String fileName, String key) {
        try (FileReader reader = new FileReader(fileName)) {
            Properties props = new Properties();
            props.load(reader);
            return props.getProperty(key);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}

